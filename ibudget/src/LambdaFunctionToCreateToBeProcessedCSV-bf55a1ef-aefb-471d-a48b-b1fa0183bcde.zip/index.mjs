// Import AWS SDK and other necessary modules
import AWS from 'aws-sdk';

// Initialize AWS S3 client
const s3 = new AWS.S3();

// Configure the necessary variables
const BUCKET_NAME = 'ibudget-purchases-bucket';
const FILE_KEY = 'unprocessedInputs/To_Be_Processed.csv';
const HEADERS = 'username,purchaseId,category,customerID,discount,itemName,paymentMethod,price,quantity,storeLocation,storeName,totalAmount,transactionDate\n';

export const handler = async (event) => {
    try {
        // Process each record from the DynamoDB stream
        for (const record of event.Records) {
            if (record.eventName === 'INSERT') {
                const newImage = AWS.DynamoDB.Converter.unmarshall(record.dynamodb.NewImage);
                const newRow = formatRow(newImage);

                // Ensure the file exists and has headers
                const fileContent = await getFileContent();
                const updatedContent = ensureHeaders(fileContent, newRow);

                // Upload the updated content back to S3
                await uploadToS3(updatedContent);
            }
        }

        return {
            statusCode: 200,
            body: JSON.stringify('Lambda function executed successfully!'),
        };
    } catch (error) {
        console.error('Error processing DynamoDB stream:', error);
        return {
            statusCode: 500,
            body: JSON.stringify('Error processing the stream.'),
        };
    }
};

// Format the DynamoDB record into a CSV row
function formatRow(record) {
    return `${record.username},${record.purchaseId},${record.category},${record.customerID},${record.discount},${record.itemName},${record.paymentMethod},${record.price},${record.quantity},${record.storeLocation},${record.storeName},${record.totalAmount},${record.transactionDate}\n`;
}

// Retrieve the existing content of the file from S3
async function getFileContent() {
    try {
        const data = await s3.getObject({
            Bucket: BUCKET_NAME,
            Key: FILE_KEY,
        }).promise();
        return data.Body.toString('utf-8');
    } catch (error) {
        if (error.code === 'NoSuchKey') {
            console.log('File does not exist, initializing with headers.');
            return '';
        } else {
            throw error;
        }
    }
}

// Ensure the file has headers and append the new row
function ensureHeaders(fileContent, newRow) {
    if (!fileContent || !fileContent.startsWith(HEADERS)) {
        console.log('Adding headers to the file.');
        return HEADERS + newRow;
    }
    return fileContent + newRow;
}

// Upload the updated file back to S3
async function uploadToS3(content) {
    await s3.putObject({
        Bucket: BUCKET_NAME,
        Key: FILE_KEY,
        Body: content,
        ContentType: 'text/csv',
    }).promise();
    console.log('File successfully updated in S3.');
}
