// Import necessary AWS SDK modules
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import DynamoDBPkg from "@aws-sdk/client-dynamodb"; // Import all of client-dynamodb as DynamoDBPkg
import { DynamoDBDocumentClient, ScanCommand, BatchWriteCommand } from "@aws-sdk/lib-dynamodb";
import { parse } from "csv-parse/sync";

// Destructure the DynamoDBClient from the imported DynamoDBPkg
const { DynamoDBClient } = DynamoDBPkg;

// Initialize AWS SDK clients
const s3 = new S3Client();
const dynamoDB = DynamoDBDocumentClient.from(new DynamoDBClient());

// Define the DynamoDB table name and S3 bucket details
const RECOMMENDATIONS_TABLE = "Recommendations";
const BUCKET_NAME = "ibudget-purchases-bucket";
const FILE_KEY = "ml-output-data/Retail_Transaction_ML.csv";

export const handler = async (event) => {
  try {
    // Step 1: Empty the Recommendations table
    await emptyTable(RECOMMENDATIONS_TABLE);

    // Step 2: Fetch and parse the CSV file from S3
    const csvData = await getCSVFromS3(BUCKET_NAME, FILE_KEY);
    const parsedData = parseCSV(csvData);

    // Step 3: Populate the Recommendations table with new data
    await populateTable(RECOMMENDATIONS_TABLE, parsedData);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Table updated successfully." }),
    };
  } catch (error) {
    console.error("Error processing request:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Internal server error.", error: error.message }),
    };
  }
};

async function emptyTable(tableName) {
  const scanCommand = new ScanCommand({ TableName: tableName });
  const data = await dynamoDB.send(scanCommand);

  // Prepare delete requests
  const deleteRequests = data.Items.map((item) => ({
    DeleteRequest: {
      Key: { customerID: item.customerID }, // Replace with your table's primary key
    },
  }));

  // Chunk into batches of 25 items
  const batches = chunkArray(deleteRequests, 25);

  // Send batch delete requests
  for (const batch of batches) {
    const batchCommand = new BatchWriteCommand({
      RequestItems: {
        [tableName]: batch,
      },
    });
    await dynamoDB.send(batchCommand);
  }

  console.log(`Table ${tableName} has been emptied.`);
}

async function getCSVFromS3(bucketName, fileKey) {
  const getObjectCommand = new GetObjectCommand({
    Bucket: bucketName,
    Key: fileKey,
  });
  const response = await s3.send(getObjectCommand);

  const streamToString = (stream) =>
    new Promise((resolve, reject) => {
      const chunks = [];
      stream.on("data", (chunk) => chunks.push(chunk));
      stream.on("error", reject);
      stream.on("end", () => resolve(Buffer.concat(chunks).toString("utf-8")));
    });

  return streamToString(response.Body);
}

function parseCSV(csvData) {
  // Split CSV data into rows
  const rows = csvData.split("\n");

  // Skip the header row and process remaining rows
  const result = [];
  for (let i = 1; i < rows.length; i++) {
    const row = rows[i].trim();
    if (!row) continue; // Skip empty rows

    // Use a regex to safely split by commas, accounting for quotes
    const columns = row.match(/(?:\"[^\"]*\"|[^,])+/g);

    if (columns && columns.length > 9) {
      try {
        // Extract customerID and recommendations
        const customerID = parseInt(columns[0].replace(/['"]/g, ""), 10); // Remove quotes
        const recommendations = columns[9].replace(/['"]/g, "").trim(); // Remove quotes and whitespace

        if (!isNaN(customerID) && recommendations) {
          result.push({ customerID, recommendations });
        }
      } catch (error) {
        console.error(`Error processing row ${i}:`, error);
      }
    }
  }

  return result;
}

async function populateTable(tableName, data) {
  // Prepare put requests
  const putRequests = data.map((item) => ({
    PutRequest: {
      Item: item,
    },
  }));

  // Chunk into batches of 25 items
  const batches = chunkArray(putRequests, 25);

  // Send batch write requests
  for (const batch of batches) {
    const batchCommand = new BatchWriteCommand({
      RequestItems: {
        [tableName]: batch,
      },
    });
    await dynamoDB.send(batchCommand);
  }

  console.log(`Table ${tableName} has been populated with new data.`);
}

// Utility function to chunk an array into smaller arrays of a given size
function chunkArray(array, size) {
  const result = [];
  for (let i = 0; i < array.length; i += size) {
    result.push(array.slice(i, i + size));
  }
  return result;
}

